<!--.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio - G. Dhanush</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <?php include("header.php"); ?>

    <section id="portfolio">
        <h2>My Projects</h2>
        <?php
            // Sample dynamic content using PHP
            $projects = [
                [
                    "title" => "Project 1",
                    "description" => "This is a detailed description of the project. It involved creating a dynamic website with JavaScript, HTML, and CSS. I used frameworks like React.js for UI development and Node.js for the backend."
                ],
                [
                    "title" => "Project 2",
                    "description" => "This project was a mobile app built with Flutter. It had an intuitive interface and a smooth user experience."
                ]
                // You can add more projects to this array
            ];

            foreach ($projects as $project) {
                echo "<div class='project'>";
                echo "<h3>{$project['title']}</h3>";
                echo "<p>{$project['description']}</p>";
                echo "</div>";
            }
        ?>
    </section>

    <footer>
        <p>Made by G. Dhanush &copy; <?php echo date("Y"); ?></p>
    </footer>

</body>
</html>